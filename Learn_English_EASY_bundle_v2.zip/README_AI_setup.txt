Learn English EASY — AI connection starter

Files:
- index.html: frontend, with the AI backend URL placeholder
- worker.js: Cloudflare Worker backend source

Important:
1. This package is NOT live yet.
2. Create a Cloudflare Worker and enable/bind Workers AI as the variable named AI.
3. Deploy worker.js, then copy the Worker URL.
4. In index.html, replace PASTE_YOUR_CLOUDFLARE_WORKER_URL_HERE with the Worker URL.
5. Upload the updated index.html to your static host.

The worker uses a public CORS policy for a simple prototype. Because the endpoint is public, other people may call it and consume your free quota. Before sharing widely, configure rate limiting and review Cloudflare account/age requirements with a parent or guardian if needed.
The selected model ID may need to be changed if Cloudflare's model catalog or account availability differs.
